'use strict';

/* ══════════════════════════════════════════════════════
   NestShare v3 — Dashboard
   Handles: navigation, file upload, file list, send
   file to online users, receive transfer requests,
   presence updates, transfer history
══════════════════════════════════════════════════════ */

/* ── Toast ─────────────────────────────────────────── */
function toast(msg, type = 'info', ms = 4000) {
  const c  = document.getElementById('toasts');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  c.appendChild(el);
  setTimeout(() => el.remove(), ms);
}

/* ── View routing ──────────────────────────────────── */
const viewCallbacks = {
  files:   loadFiles,
  share:   loadRecipients,
  users:   loadUsers,
  history: loadHistory,
};

function showView(name) {
  document.querySelectorAll('.view').forEach(v =>
    v.classList.toggle('active', v.id === `view-${name}`)
  );
  document.querySelectorAll('.sb-btn, .mn-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.view === name)
  );
  if (viewCallbacks[name]) viewCallbacks[name]();
}

document.querySelectorAll('[data-view]').forEach(el =>
  el.addEventListener('click', () => showView(el.dataset.view))
);

/* ── File emoji ────────────────────────────────────── */
function fEmoji(name) {
  const e = (name.split('.').pop() || '').toLowerCase();
  const m = {
    jpg:'🖼️',jpeg:'🖼️',png:'🖼️',gif:'🖼️',webp:'🖼️',svg:'🖼️',bmp:'🖼️',heic:'🖼️',
    mp4:'🎬',mkv:'🎬',avi:'🎬',mov:'🎬',webm:'🎬',
    mp3:'🎵',wav:'🎵',ogg:'🎵',flac:'🎵',aac:'🎵',m4a:'🎵',
    pdf:'📕',
    doc:'📝',docx:'📝',
    xls:'📊',xlsx:'📊',csv:'📊',
    ppt:'📋',pptx:'📋',
    zip:'🗜️',tar:'🗜️',gz:'🗜️',rar:'🗜️','7z':'🗜️',
    py:'💻',js:'💻',ts:'💻',html:'💻',css:'💻',sh:'💻',c:'💻',cpp:'💻',java:'💻',rs:'💻',go:'💻',
    txt:'📄',md:'📄',log:'📄',json:'📄',
    apk:'📱',exe:'⚙️',deb:'⚙️',
    iso:'💿',
  };
  return m[e] || '📁';
}

function fmtBytes(s) {
  const units = ['B','KB','MB','GB'];
  let n = parseFloat(s); // already human-readable from server
  return s; // server already formats it
}

/* ═══════════════════════════════════════════════════════
   MY FILES
═══════════════════════════════════════════════════════ */
let allFiles = [];

async function loadFiles() {
  const wrap = document.getElementById('files-wrap');
  const cnt  = document.getElementById('file-count');
  wrap.innerHTML = `<div class="state-box"><div class="spin-lg"></div><p>Loading…</p></div>`;
  try {
    const r = await fetch('/api/files');
    allFiles = await r.json();
    cnt.textContent = `${allFiles.length} file${allFiles.length !== 1 ? 's' : ''} — encrypted at rest`;
    renderFiles(allFiles);
  } catch(e) {
    wrap.innerHTML = `<div class="state-box"><div class="state-ico">⚠️</div><p>Failed to load.</p></div>`;
  }
}

function renderFiles(list) {
  const wrap = document.getElementById('files-wrap');
  const cnt  = document.getElementById('file-count');
  cnt.textContent = `${list.length} file${list.length !== 1 ? 's' : ''} — encrypted at rest`;
  if (!list.length) {
    wrap.innerHTML = `<div class="state-box"><div class="state-ico">📭</div><p>No files yet.</p></div>`;
    return;
  }
  const grid = document.createElement('div');
  grid.className = 'file-grid';
  list.forEach(f => grid.appendChild(mkCard(f)));
  wrap.innerHTML = '';
  wrap.appendChild(grid);
}

function mkCard(f) {
  const d = document.createElement('div');
  d.className = 'f-card';
  d.innerHTML = `
    <div class="f-icon">${fEmoji(f.name)}</div>
    <div class="f-name" title="${f.name}">${f.name}</div>
    <div class="f-meta">${f.modified}</div>
    <div class="f-meta">${f.size_hr}</div>
    <div class="f-actions">
      <button class="btn-ghost" onclick="dlFile('${encodeURIComponent(f.name)}')">
        <svg width="12" height="12" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
        Download
      </button>
      <button class="btn-ghost del" onclick="rmFile('${f.name.replace(/'/g,"\\'")}',this)">
        <svg width="12" height="12" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
        Delete
      </button>
      <button class="btn-ghost share-btn" onclick="openShareModal('${f.name.replace(/'/g,"\\'")}')">
        <svg width="12" height="12" viewBox="0 0 20 20" fill="currentColor"><path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z"/></svg>
        Share
      </button>
    </div>`;
  return d;
}

document.getElementById('search-in').addEventListener('input', function() {
  renderFiles(allFiles.filter(f => f.name.toLowerCase().includes(this.value.toLowerCase())));
});
document.getElementById('refresh-btn').addEventListener('click', loadFiles);

function dlFile(enc) {
  const a = document.createElement('a');
  a.href = `/download/${enc}`;
  a.download = decodeURIComponent(enc);
  document.body.appendChild(a); a.click(); a.remove();
}

async function rmFile(name, btn) {
  if (!confirm(`Delete "${name}"?`)) return;
  btn.disabled = true;
  try {
    const r = await fetch(`/api/delete/${encodeURIComponent(name)}`, { method: 'DELETE' });
    const d = await r.json();
    if (d.ok) { allFiles = allFiles.filter(f => f.name !== name); renderFiles(allFiles); toast(`Deleted "${name}"`, 'ok'); }
    else { toast(d.error || 'Delete failed', 'err'); btn.disabled = false; }
  } catch(e) { toast('Network error', 'err'); btn.disabled = false; }
}

/* ═══════════════════════════════════════════════════════
   UPLOAD
═══════════════════════════════════════════════════════ */
const dropZone  = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-in');
const queueEl   = document.getElementById('queue');
const uploadBtn = document.getElementById('upload-btn');

let pending = [];
function uid() { return Math.random().toString(36).slice(2, 9); }

function addFiles(files) {
  for (const f of files) {
    const id = uid();
    pending.push({ file: f, id });
    const item = document.createElement('div');
    item.className = 'q-item'; item.id = `qi-${id}`;
    item.innerHTML = `
      <div class="q-ico">${fEmoji(f.name)}</div>
      <div class="q-info">
        <div class="q-name">${f.name}</div>
        <div class="q-size">${humanBytes(f.size)}</div>
        <div class="q-bar-bg"><div class="q-bar" id="bar-${id}"></div></div>
        <div class="q-st" id="st-${id}">Queued</div>
      </div>
      <button class="q-rm" data-id="${id}">
        <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
      </button>`;
    queueEl.appendChild(item);
  }
  syncUploadBtn();
}

function humanBytes(n) {
  const u = ['B','KB','MB','GB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(1)} ${u[i]}`;
}

queueEl.addEventListener('click', e => {
  const rm = e.target.closest('.q-rm');
  if (!rm) return;
  const id = rm.dataset.id;
  pending = pending.filter(p => p.id !== id);
  document.getElementById(`qi-${id}`)?.remove();
  syncUploadBtn();
});

function syncUploadBtn() {
  uploadBtn.style.display = pending.length ? 'inline-flex' : 'none';
}

['dragenter','dragover'].forEach(ev => dropZone.addEventListener(ev, e => { e.preventDefault(); dropZone.classList.add('over'); }));
['dragleave','dragend'].forEach(ev => dropZone.addEventListener(ev, e => { if (!dropZone.contains(e.relatedTarget)) dropZone.classList.remove('over'); }));
dropZone.addEventListener('drop', e => { e.preventDefault(); dropZone.classList.remove('over'); addFiles([...e.dataTransfer.files]); });
dropZone.addEventListener('click', e => { if (!e.target.closest('.dz-pick')) fileInput.click(); });
document.querySelector('.dz-pick').addEventListener('click', e => { e.stopPropagation(); fileInput.click(); });
fileInput.addEventListener('change', () => { if (fileInput.files.length) addFiles([...fileInput.files]); fileInput.value = ''; });

uploadBtn.addEventListener('click', async () => {
  if (!pending.length) return;
  const lbl  = uploadBtn.querySelector('.btn-label');
  const spin = uploadBtn.querySelector('.spinner');
  uploadBtn.disabled = true; lbl.style.display = 'none'; spin.style.display = 'inline-block';

  const batch = [...pending]; let ok = 0;
  for (const { file, id } of batch) {
    const item = document.getElementById(`qi-${id}`);
    const bar  = document.getElementById(`bar-${id}`);
    const st   = document.getElementById(`st-${id}`);
    if (!item) continue;
    item.classList.add('uploading'); st.textContent = 'Uploading…';
    const fd = new FormData(); fd.append('files', file);
    try {
      await new Promise((res, rej) => {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/upload');
        xhr.upload.onprogress = e => { if (e.lengthComputable) bar.style.width = `${Math.round(e.loaded/e.total*100)}%`; };
        xhr.onload = () => {
          if (xhr.status === 200) {
            const d = JSON.parse(xhr.responseText);
            if (d.results?.[0]?.ok) { res(); return; }
            rej(new Error(d.results?.[0]?.error || 'Failed'));
          } else {
            let m = `HTTP ${xhr.status}`;
            try { m = JSON.parse(xhr.responseText).error || m; } catch(_){}
            rej(new Error(m));
          }
        };
        xhr.onerror = () => rej(new Error('Network error'));
        xhr.send(fd);
      });
      item.classList.remove('uploading'); item.classList.add('done');
      st.textContent = '✓ Uploaded (encrypted)';
      pending = pending.filter(p => p.id !== id); ok++;
    } catch(err) {
      item.classList.remove('uploading'); item.classList.add('failed');
      st.textContent = `✗ ${err.message}`;
    }
  }
  uploadBtn.disabled = false; lbl.style.display = ''; spin.style.display = 'none';
  syncUploadBtn();
  if (ok > 0) toast(`${ok} file${ok > 1 ? 's' : ''} uploaded & encrypted!`, 'ok');
  setTimeout(() => { document.querySelectorAll('.q-item.done').forEach(el => el.remove()); syncUploadBtn(); }, 2500);
});

/* ═══════════════════════════════════════════════════════
   SEND FILE — STEP 2: RECIPIENTS
═══════════════════════════════════════════════════════ */
let selectedRecipient = null;
let sendFileObj       = null;

document.getElementById('send-file-in').addEventListener('change', function() {
  const lbl = document.getElementById('send-file-lbl');
  if (this.files[0]) {
    sendFileObj = this.files[0];
    lbl.innerHTML = `<svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg> ${sendFileObj.name}`;
    lbl.classList.add('selected');
  } else {
    sendFileObj = null;
    lbl.innerHTML = `<svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18"><path fill-rule="evenodd" d="M8 4a3 3 0 00-3 3v4a5 5 0 0010 0V7a1 1 0 112 0v4a7 7 0 11-14 0V7a5 5 0 0110 0v4a3 3 0 11-6 0V7a1 1 0 012 0v4a1 1 0 102 0V7a3 3 0 00-3-3z" clip-rule="evenodd"/></svg> Click to select file`;
    lbl.classList.remove('selected');
  }
  syncSendBtn();
});

async function loadRecipients() {
  selectedRecipient = null;
  syncSendBtn();
  const wrap = document.getElementById('recipient-list');
  wrap.innerHTML = `<div class="state-box compact"><div class="spin-lg"></div></div>`;
  try {
    const r = await fetch('/api/online-users');
    const users = await r.json();
    if (!users.length) {
      wrap.innerHTML = `<div class="no-online">No users are online right now.<br>Ask them to open NestShare!</div>`;
      return;
    }
    const grid = document.createElement('div');
    grid.className = 'recipient-grid';
    users.forEach(u => {
      const item = document.createElement('div');
      item.className = 'rec-item';
      item.dataset.username = u.username;
      item.innerHTML = `
        <div class="rec-av">${u.display[0].toUpperCase()}</div>
        <div class="rec-info">
          <div class="rec-display">${u.display}</div>
          <div class="rec-handle">@${u.username}</div>
        </div>
        <div class="rec-dot"></div>`;
      item.addEventListener('click', () => {
        document.querySelectorAll('.rec-item').forEach(i => i.classList.remove('selected'));
        item.classList.add('selected');
        selectedRecipient = u.username;
        syncSendBtn();
      });
      grid.appendChild(item);
    });
    wrap.innerHTML = '';
    wrap.appendChild(grid);
  } catch(e) {
    wrap.innerHTML = `<div class="no-online">Failed to load users.</div>`;
  }
}

function syncSendBtn() {
  document.getElementById('send-btn').disabled = !(selectedRecipient && sendFileObj);
}

document.getElementById('send-btn').addEventListener('click', async () => {
  if (!sendFileObj || !selectedRecipient) return;
  const btn  = document.getElementById('send-btn');
  const lbl  = btn.querySelector('.btn-label');
  const spin = btn.querySelector('.spinner');
  btn.disabled = true; lbl.style.display = 'none'; spin.style.display = 'inline-block';

  const fd = new FormData();
  fd.append('file', sendFileObj);
  fd.append('receiver', selectedRecipient);

  try {
    const r = await fetch('/api/transfer/initiate', { method: 'POST', body: fd });
    const d = await r.json();
    if (d.ok) {
      toast(`Transfer request sent to @${selectedRecipient}!`, 'ok');
      // Reset
      sendFileObj = null; selectedRecipient = null;
      document.getElementById('send-file-in').value = '';
      const lbl2 = document.getElementById('send-file-lbl');
      lbl2.classList.remove('selected');
      lbl2.innerHTML = `<svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18"><path fill-rule="evenodd" d="M8 4a3 3 0 00-3 3v4a5 5 0 0010 0V7a1 1 0 112 0v4a7 7 0 11-14 0V7a5 5 0 0110 0v4a3 3 0 11-6 0V7a1 1 0 012 0v4a1 1 0 102 0V7a3 3 0 00-3-3z" clip-rule="evenodd"/></svg> Click to select file`;
      document.querySelectorAll('.rec-item').forEach(i => i.classList.remove('selected'));
    } else {
      toast(d.error || 'Send failed', 'err');
    }
  } catch(e) { toast('Network error', 'err'); }

  btn.disabled = false; lbl.style.display = ''; spin.style.display = 'none';
  syncSendBtn();
});

/* ═══════════════════════════════════════════════════════
   USERS VIEW
═══════════════════════════════════════════════════════ */
let _allUsersCache = [];

async function loadUsers() {
  const wrap = document.getElementById('users-wrap');
  wrap.innerHTML = `<div class="state-box"><div class="spin-lg"></div><p>Loading…</p></div>`;
  try {
    const r = await fetch('/api/all-users');
    _allUsersCache = await r.json();
    renderUsersView(_allUsersCache);
  } catch(e) {
    wrap.innerHTML = `<div class="state-box"><div class="state-ico">⚠️</div><p>Failed to load.</p></div>`;
  }
}

function renderUsersView(users) {
  const wrap = document.getElementById('users-wrap');
  if (!users.length) {
    wrap.innerHTML = `<div class="state-box"><div class="state-ico">👥</div><p>No other users yet.</p></div>`;
    return;
  }
  const grid = document.createElement('div');
  grid.className = 'users-grid';
  // Sort: online first
  const sorted = [...users].sort((a,b) => (b.online ? 1:0) - (a.online ? 1:0));
  sorted.forEach(u => {
    const card = document.createElement('div');
    card.className = `user-card${u.online ? ' is-online' : ''}`;
    card.innerHTML = `
      <div class="u-av">${u.display[0].toUpperCase()}</div>
      <div class="u-info">
        <div class="u-display">${u.display}</div>
        <div class="u-handle">@${u.username}</div>
      </div>
      <div class="u-status ${u.online ? 'online' : 'offline'}">${u.online ? '● Online' : 'Offline'}</div>`;
    grid.appendChild(card);
  });
  wrap.innerHTML = '';
  wrap.appendChild(grid);
}

/* ═══════════════════════════════════════════════════════
   HISTORY
═══════════════════════════════════════════════════════ */
async function loadHistory() {
  const wrap = document.getElementById('history-wrap');
  wrap.innerHTML = `<div class="state-box"><div class="spin-lg"></div><p>Loading…</p></div>`;
  try {
    const r = await fetch('/api/transfer/history');
    const items = await r.json();
    if (!items.length) {
      wrap.innerHTML = `<div class="state-box"><div class="state-ico">📋</div><p>No transfers yet.</p></div>`;
      return;
    }
    const list = document.createElement('div');
    list.className = 'hist-list';
    items.forEach(t => {
      const isSent = t.sender === _currentUser;
      const item   = document.createElement('div');
      item.className = 'hist-item';
      item.innerHTML = `
        <div class="hist-ico ${isSent ? 'sent' : 'recv'}">
          ${isSent ? '↑' : '↓'}
        </div>
        <div class="hist-body">
          <div class="hist-title">${t.filename}</div>
          <div class="hist-sub">${isSent ? `Sent to @${t.receiver}` : `From @${t.sender}`} · ${t.created?.slice(0,16).replace('T',' ') || ''}</div>
        </div>
        <div class="hist-badge ${t.status}">${t.status}</div>`;
      list.appendChild(item);
    });
    wrap.innerHTML = '';
    wrap.appendChild(list);
  } catch(e) {
    wrap.innerHTML = `<div class="state-box"><div class="state-ico">⚠️</div><p>Failed to load.</p></div>`;
  }
}
document.getElementById('hist-refresh').addEventListener('click', loadHistory);

/* ═══════════════════════════════════════════════════════
   SHARE FROM MY FILES — modal
═══════════════════════════════════════════════════════ */
let _shareFilename      = null;
let _shareRecipient     = null;

async function openShareModal(filename) {
  _shareFilename  = filename;
  _shareRecipient = null;

  // Reset UI
  document.getElementById('share-modal-filename').textContent = `📄 ${filename}`;
  document.getElementById('share-send-btn').disabled = true;

  const list = document.getElementById('share-user-list');
  list.innerHTML = `<div class="state-box compact"><div class="spin-lg"></div></div>`;
  document.getElementById('share-modal').style.display = 'flex';

  // Fetch online users
  try {
    const r     = await fetch('/api/online-users');
    const users = await r.json();

    if (!users.length) {
      list.innerHTML = `<div class="no-online">No users are online right now.</div>`;
      return;
    }

    list.innerHTML = '';
    users.forEach(u => {
      const item = document.createElement('div');
      item.className = 'rec-item';
      item.dataset.username = u.username;
      item.innerHTML = `
        <div class="rec-av">${u.display[0].toUpperCase()}</div>
        <div class="rec-info">
          <div class="rec-display">${u.display}</div>
          <div class="rec-handle">@${u.username}</div>
        </div>
        <div class="rec-dot"></div>`;
      item.addEventListener('click', () => {
        list.querySelectorAll('.rec-item').forEach(i => i.classList.remove('selected'));
        item.classList.add('selected');
        _shareRecipient = u.username;
        document.getElementById('share-send-btn').disabled = false;
      });
      list.appendChild(item);
    });
  } catch(e) {
    list.innerHTML = `<div class="no-online">Failed to load users.</div>`;
  }
}

function closeShareModal() {
  document.getElementById('share-modal').style.display = 'none';
  _shareFilename  = null;
  _shareRecipient = null;
}

async function doShareSend() {
  if (!_shareFilename || !_shareRecipient) return;

  const btn  = document.getElementById('share-send-btn');
  const lbl  = btn.querySelector('.btn-label');
  const spin = btn.querySelector('.spinner');
  btn.disabled = true; lbl.style.display = 'none'; spin.style.display = 'inline-block';

  try {
    // Fetch the encrypted file from the server, decrypt on-the-fly via download,
    // then re-upload as a transfer — we do this by asking the server to initiate
    // a server-side transfer directly from the vault.
    const r = await fetch('/api/transfer/initiate-from-vault', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ filename: _shareFilename, receiver: _shareRecipient }),
    });
    const d = await r.json();
    if (d.ok) {
      toast(`Sent "${_shareFilename}" to @${_shareRecipient}!`, 'ok');
      closeShareModal();
    } else {
      toast(d.error || 'Send failed', 'err');
      btn.disabled = false; lbl.style.display = ''; spin.style.display = 'none';
    }
  } catch(e) {
    toast('Network error', 'err');
    btn.disabled = false; lbl.style.display = ''; spin.style.display = 'none';
  }
}

// Close modal when clicking the overlay background
document.getElementById('share-modal').addEventListener('click', function(e) {
  if (e.target === this) closeShareModal();
});

/* ═══════════════════════════════════════════════════════
   SOCKET.IO — REAL-TIME
═══════════════════════════════════════════════════════ */
const socket = io({ transports: ['websocket','polling'] });

// Current pending request (only one at a time displayed)
let _pendingTid = null;
let _currentUser = document.querySelector('.sb-handle')?.textContent?.replace('@','') || '';

socket.on('connect', () => {
  console.log('[NestShare] Connected, SID:', socket.id);
});

socket.on('disconnect', () => {
  console.log('[NestShare] Disconnected');
});

/* Presence update — fired by server whenever someone connects/disconnects */
socket.on('presence_update', (onlineList) => {
  // onlineList: [{username, display}, ...]
  const count = onlineList.filter(u => u.username !== _currentUser).length;

  // Update sidebar badge
  const badge = document.getElementById('sb-online-count');
  if (badge) badge.textContent = count;

  // If users view is active, refresh it
  const usersView = document.getElementById('view-users');
  if (usersView?.classList.contains('active')) loadUsers();

  // If share view is active, refresh recipients
  const shareView = document.getElementById('view-share');
  if (shareView?.classList.contains('active')) loadRecipients();
});

/* Incoming transfer request */
socket.on('transfer_request', (data) => {
  // data: { tid, sender, sender_display, filename, size_hr }
  _pendingTid = data.tid;

  document.getElementById('req-body').textContent =
    `${data.sender_display} (@${data.sender}) wants to send you a file.`;
  document.getElementById('req-filename').textContent = `📄 ${data.filename}`;
  document.getElementById('req-size').textContent    = `💾 ${data.size_hr}`;

  document.getElementById('req-modal').style.display = 'flex';

  // Vibrate on mobile (if supported)
  if ('vibrate' in navigator) navigator.vibrate([100, 50, 100]);
});

/* Transfer response (sender gets this) */
socket.on('transfer_response', (data) => {
  // data: { tid, filename, receiver, receiver_display, accepted }
  if (data.accepted) {
    toast(`✓ ${data.receiver_display} accepted "${data.filename}"`, 'ok', 5000);
  } else {
    toast(`${data.receiver_display} declined "${data.filename}"`, 'warn', 5000);
  }
  // Refresh history if open
  const hView = document.getElementById('view-history');
  if (hView?.classList.contains('active')) loadHistory();
});

/* ── Transfer modal buttons ─────────────────────────── */
document.getElementById('req-accept').addEventListener('click', () => respondTransfer(true));
document.getElementById('req-reject').addEventListener('click', () => respondTransfer(false));

async function respondTransfer(accept) {
  const modal = document.getElementById('req-modal');
  const tid   = _pendingTid;
  modal.style.display = 'none';
  _pendingTid = null;

  try {
    const r = await fetch('/api/transfer/respond', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ tid, accept })
    });
    const d = await r.json();
    if (d.ok) {
      if (accept) {
        toast('File saved to your vault! 🔐', 'ok', 5000);
        // If files view is open, refresh
        if (document.getElementById('view-files').classList.contains('active')) loadFiles();
      } else {
        toast('Transfer declined.', 'info');
      }
    } else {
      toast(d.error || 'Failed to respond', 'err');
    }
  } catch(e) { toast('Network error', 'err'); }
}

/* ═══════════════════════════════════════════════════════
   INIT
═══════════════════════════════════════════════════════ */
showView('upload');
