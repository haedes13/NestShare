#!/usr/bin/env bash
# ── NestShare v3 — Setup & Launch ────────────────────────────
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo "  ⬡  NestShare v3 — Encrypted P2P File Sharing"
echo "  ──────────────────────────────────────────────"

# Python check
if ! command -v python3 &>/dev/null; then
  echo "  [ERROR] python3 not found."
  exit 1
fi

# Virtualenv
if [ ! -d ".venv" ]; then
  echo "  [*] Creating virtual environment…"
  python3 -m venv .venv
fi

source .venv/bin/activate

echo "  [*] Installing dependencies…"
pip install -q -r requirements.txt

# Create required directories
mkdir -p uploads inbox temp_transfers
chmod 700 uploads inbox temp_transfers

# Protect secret key files if they exist
[ -f .secret_key  ] && chmod 600 .secret_key
[ -f .flask_secret] && chmod 600 .flask_secret

# Get LAN IP
LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "0.0.0.0")

echo ""
echo "  [✓] NestShare is starting…"
echo ""
echo "  Local:    http://127.0.0.1:5000"
echo "  Network:  http://${LOCAL_IP}:5000"
echo ""
echo "  Security:"
echo "   ● Passwords: bcrypt (12 rounds)"
echo "   ● Files:     AES-128 Fernet encryption at rest"
echo "   ● Master key: $(pwd)/.secret_key (chmod 600)"
echo ""
echo "  Uploads: $(pwd)/uploads/<username>/"
echo "  Press Ctrl+C to stop."
echo ""

python3 app.py
