"""
NestShare v3 — Encrypted P2P File Sharing
==========================================
Security model:
  • Passwords: bcrypt (12 rounds) — never stored in plaintext
  • Files: AES-128 (Fernet) encrypted at rest using a master key
            stored in .secret_key  — only loaded at runtime
  • Per-user isolation: each user has their own encrypted vault directory
  • Transfers: encrypted at rest, receiver must accept before file appears
  • Sessions: server-side secret, regenerated on login
"""

import os, json, uuid, mimetypes, secrets, base64
from datetime import datetime, timedelta
from functools import wraps

import bcrypt
from cryptography.fernet import Fernet
from flask import (Flask, render_template, request, redirect, url_for,
                   session, jsonify, abort, Response, stream_with_context)
from flask_socketio import SocketIO, emit, join_room, leave_room, disconnect
from werkzeug.utils import secure_filename

# ─────────────────────────────────────────────────────────────────────────────
#  App setup
# ─────────────────────────────────────────────────────────────────────────────
app = Flask(__name__)

BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
SECRET_FILE   = os.path.join(BASE_DIR, '.secret_key')
USERS_FILE    = os.path.join(BASE_DIR, 'users.json')
UPLOAD_ROOT   = os.path.join(BASE_DIR, 'uploads')    # encrypted vaults
INBOX_ROOT    = os.path.join(BASE_DIR, 'inbox')      # pending transfers
TRANSFERS_FILE= os.path.join(BASE_DIR, 'transfers.json')

MAX_MB        = 500
BCRYPT_ROUNDS = 12

app.config['MAX_CONTENT_LENGTH'] = MAX_MB * 1024 * 1024

for d in [UPLOAD_ROOT, INBOX_ROOT]:
    os.makedirs(d, exist_ok=True)

# ── Master encryption key ─────────────────────────────────────────────────────
def _load_or_create_key():
    if os.path.exists(SECRET_FILE):
        with open(SECRET_FILE, 'rb') as f:
            return f.read().strip()
    key = Fernet.generate_key()
    with open(SECRET_FILE, 'wb') as f:
        f.write(key)
    os.chmod(SECRET_FILE, 0o600)
    return key

MASTER_KEY = _load_or_create_key()
FERNET     = Fernet(MASTER_KEY)

# Flask secret (separate from file encryption key)
FLASK_SECRET_FILE = os.path.join(BASE_DIR, '.flask_secret')
if os.path.exists(FLASK_SECRET_FILE):
    with open(FLASK_SECRET_FILE, 'rb') as f:
        app.secret_key = f.read()
else:
    app.secret_key = secrets.token_bytes(32)
    with open(FLASK_SECRET_FILE, 'wb') as f:
        f.write(app.secret_key)
    os.chmod(FLASK_SECRET_FILE, 0o600)

socketio = SocketIO(app, cors_allowed_origins='*', async_mode='eventlet')

# ─────────────────────────────────────────────────────────────────────────────
#  Online users registry  { username → sid }
# ─────────────────────────────────────────────────────────────────────────────
online_users: dict[str, str] = {}   # username → socket-id

# ─────────────────────────────────────────────────────────────────────────────
#  Helpers — users
# ─────────────────────────────────────────────────────────────────────────────
def load_users() -> dict:
    if not os.path.exists(USERS_FILE):
        return {}
    with open(USERS_FILE) as f:
        return json.load(f)

def save_users(u: dict):
    with open(USERS_FILE, 'w') as f:
        json.dump(u, f, indent=2)

def hash_pw(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt(BCRYPT_ROUNDS)).decode()

def check_pw(pw: str, hashed: str) -> bool:
    return bcrypt.checkpw(pw.encode(), hashed.encode())

# ─────────────────────────────────────────────────────────────────────────────
#  Helpers — file encryption
# ─────────────────────────────────────────────────────────────────────────────
def user_vault(username: str) -> str:
    p = os.path.join(UPLOAD_ROOT, secure_filename(username))
    os.makedirs(p, exist_ok=True)
    return p

def user_inbox(username: str) -> str:
    p = os.path.join(INBOX_ROOT, secure_filename(username))
    os.makedirs(p, exist_ok=True)
    return p

def encrypt_file(data: bytes) -> bytes:
    return FERNET.encrypt(data)

def decrypt_file(data: bytes) -> bytes:
    return FERNET.decrypt(data)

def human_size(n: int) -> str:
    for u in ['B','KB','MB','GB']:
        if n < 1024: return f'{n:.1f} {u}'
        n /= 1024
    return f'{n:.1f} TB'

# ─────────────────────────────────────────────────────────────────────────────
#  Helpers — transfers db
# ─────────────────────────────────────────────────────────────────────────────
def load_transfers() -> dict:
    if not os.path.exists(TRANSFERS_FILE):
        return {}
    with open(TRANSFERS_FILE) as f:
        return json.load(f)

def save_transfers(t: dict):
    with open(TRANSFERS_FILE, 'w') as f:
        json.dump(t, f, indent=2)

# ─────────────────────────────────────────────────────────────────────────────
#  Auth decorator
# ─────────────────────────────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def deco(*a, **kw):
        if 'username' not in session:
            if request.is_json:
                return jsonify({'ok': False, 'error': 'Not authenticated'}), 401
            return redirect(url_for('login'))
        return f(*a, **kw)
    return deco

# ─────────────────────────────────────────────────────────────────────────────
#  Auth routes
# ─────────────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return redirect(url_for('dashboard') if 'username' in session else url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        d = request.get_json(silent=True) or request.form
        username = (d.get('username') or '').strip().lower()
        password =  d.get('password') or ''
        users = load_users()
        user  = users.get(username)
        if user and check_pw(password, user['password']):
            session.clear()
            session['username'] = username
            session['display']  = user.get('display', username)
            if request.is_json:
                return jsonify({'ok': True})
            return redirect(url_for('dashboard'))
        if request.is_json:
            return jsonify({'ok': False, 'error': 'Invalid username or password'}), 401
    return render_template('login.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        d = request.get_json(silent=True) or request.form
        username = (d.get('username') or '').strip().lower()
        display  = (d.get('display')  or username).strip()
        password =  d.get('password') or ''
        confirm  =  d.get('confirm')  or ''

        error = None
        if len(username) < 3:
            error = 'Username must be at least 3 characters.'
        elif not username.replace('_','').replace('-','').isalnum():
            error = 'Username: letters, numbers, hyphens, underscores only.'
        elif len(password) < 6:
            error = 'Password must be at least 6 characters.'
        elif password != confirm:
            error = 'Passwords do not match.'
        else:
            users = load_users()
            if username in users:
                error = 'Username already taken.'
            else:
                users[username] = {
                    'display':  display,
                    'password': hash_pw(password),
                    'created':  datetime.utcnow().isoformat(),
                }
                save_users(users)
                session.clear()
                session['username'] = username
                session['display']  = display
                # initialise vault & inbox dirs
                user_vault(username)
                user_inbox(username)
                if request.is_json:
                    return jsonify({'ok': True})
                return redirect(url_for('dashboard'))

        if request.is_json:
            return jsonify({'ok': False, 'error': error}), 400
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html',
                           username=session['username'],
                           display=session['display'])

# ─────────────────────────────────────────────────────────────────────────────
#  File API — own vault
# ─────────────────────────────────────────────────────────────────────────────
@app.route('/api/files')
@login_required
def api_files():
    vault = user_vault(session['username'])
    files = []
    for name in sorted(os.listdir(vault)):
        path = os.path.join(vault, name)
        if not os.path.isfile(path): continue
        stat = os.stat(path)
        # actual size after decryption is slightly smaller; show raw
        files.append({
            'name':     name,
            'size_hr':  human_size(stat.st_size),
            'modified': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M'),
        })
    return jsonify(files)

@app.route('/api/upload', methods=['POST'])
@login_required
def api_upload():
    if 'files' not in request.files:
        return jsonify({'ok': False, 'error': 'No files'}), 400
    vault   = user_vault(session['username'])
    results = []
    for f in request.files.getlist('files'):
        if not f.filename: continue
        safe = secure_filename(f.filename)
        dest = os.path.join(vault, safe)
        # Avoid overwrite
        if os.path.exists(dest):
            base, ext = os.path.splitext(safe)
            safe = f'{base}_{uuid.uuid4().hex[:6]}{ext}'
            dest = os.path.join(vault, safe)
        # Encrypt & store
        raw = f.read()
        enc = encrypt_file(raw)
        with open(dest, 'wb') as out:
            out.write(enc)
        results.append({'name': safe, 'ok': True, 'size_hr': human_size(len(raw))})
    return jsonify({'ok': True, 'results': results})

@app.route('/api/delete/<filename>', methods=['DELETE'])
@login_required
def api_delete(filename):
    path = os.path.join(user_vault(session['username']), secure_filename(filename))
    if not os.path.isfile(path):
        return jsonify({'ok': False, 'error': 'Not found'}), 404
    os.remove(path)
    return jsonify({'ok': True})

@app.route('/download/<filename>')
@login_required
def download_file(filename):
    path = os.path.join(user_vault(session['username']), secure_filename(filename))
    if not os.path.isfile(path):
        abort(404)
    with open(path, 'rb') as f:
        enc = f.read()
    try:
        raw = decrypt_file(enc)
    except Exception:
        abort(500)
    mime, _ = mimetypes.guess_type(filename)
    mime = mime or 'application/octet-stream'
    return Response(
        raw,
        headers={
            'Content-Disposition': f'attachment; filename="{filename}"',
            'Content-Type': mime,
            'Content-Length': len(raw),
        }
    )

# ─────────────────────────────────────────────────────────────────────────────
#  Transfer API
# ─────────────────────────────────────────────────────────────────────────────
@app.route('/api/online-users')
@login_required
def api_online_users():
    users = load_users()
    result = []
    for uname, sid in online_users.items():
        if uname == session['username']: continue
        display = users.get(uname, {}).get('display', uname)
        result.append({'username': uname, 'display': display})
    return jsonify(result)

@app.route('/api/all-users')
@login_required
def api_all_users():
    """Return all registered users with their online status."""
    users = load_users()
    result = []
    for uname, info in users.items():
        if uname == session['username']: continue
        result.append({
            'username': uname,
            'display':  info.get('display', uname),
            'online':   uname in online_users,
        })
    return jsonify(result)

@app.route('/api/transfer/initiate-from-vault', methods=['POST'])
@login_required
def api_transfer_initiate_from_vault():
    """
    Sender shares an already-uploaded file directly from their vault.
    The encrypted blob is copied (no decryption) to the temp area,
    then a socket notification is pushed to the receiver.
    """
    d        = request.get_json(silent=True) or {}
    filename = secure_filename(d.get('filename') or '')
    receiver = (d.get('receiver') or '').strip().lower()

    if not filename:
        return jsonify({'ok': False, 'error': 'Invalid filename'}), 400
    if not receiver:
        return jsonify({'ok': False, 'error': 'No receiver specified'}), 400
    if receiver not in online_users:
        return jsonify({'ok': False, 'error': 'User is offline'}), 400
    if receiver == session['username']:
        return jsonify({'ok': False, 'error': 'Cannot send to yourself'}), 400

    src = os.path.join(user_vault(session['username']), filename)
    if not os.path.isfile(src):
        return jsonify({'ok': False, 'error': 'File not found in your vault'}), 404

    # Copy encrypted blob to temp area — no decryption happens
    tid      = uuid.uuid4().hex
    temp_dir = os.path.join(BASE_DIR, 'temp_transfers')
    os.makedirs(temp_dir, exist_ok=True)
    import shutil
    shutil.copy2(src, os.path.join(temp_dir, tid))

    stat    = os.stat(src)
    size_hr = human_size(stat.st_size)

    transfers = load_transfers()
    transfers[tid] = {
        'sender':         session['username'],
        'sender_display': session['display'],
        'receiver':       receiver,
        'filename':       filename,
        'size_hr':        size_hr,
        'status':         'pending',
        'created':        datetime.utcnow().isoformat(),
    }
    save_transfers(transfers)

    receiver_sid = online_users.get(receiver)
    if receiver_sid:
        socketio.emit('transfer_request', {
            'tid':            tid,
            'sender':         session['username'],
            'sender_display': session['display'],
            'filename':       filename,
            'size_hr':        size_hr,
        }, to=receiver_sid)

    return jsonify({'ok': True, 'tid': tid})


@app.route('/api/transfer/initiate', methods=['POST'])
@login_required
def api_transfer_initiate():
    """
    Sender calls this.  We store the file encrypted in the sender's
    outbox (temp area), generate a transfer_id, then push a SocketIO
    event to the receiver.
    """
    receiver = (request.form.get('receiver') or '').strip().lower()
    if not receiver:
        return jsonify({'ok': False, 'error': 'No receiver specified'}), 400
    if receiver not in online_users:
        return jsonify({'ok': False, 'error': 'User is offline'}), 400
    if 'file' not in request.files:
        return jsonify({'ok': False, 'error': 'No file'}), 400

    f    = request.files['file']
    safe = secure_filename(f.filename)
    if not safe:
        return jsonify({'ok': False, 'error': 'Invalid filename'}), 400

    raw = f.read()
    enc = encrypt_file(raw)

    # Store in temp holding area keyed by transfer_id
    tid  = uuid.uuid4().hex
    temp_dir = os.path.join(BASE_DIR, 'temp_transfers')
    os.makedirs(temp_dir, exist_ok=True)
    temp_path = os.path.join(temp_dir, tid)
    with open(temp_path, 'wb') as out:
        out.write(enc)

    # Record transfer
    transfers = load_transfers()
    transfers[tid] = {
        'sender':    session['username'],
        'sender_display': session['display'],
        'receiver':  receiver,
        'filename':  safe,
        'size_hr':   human_size(len(raw)),
        'status':    'pending',   # pending | accepted | rejected | expired
        'created':   datetime.utcnow().isoformat(),
    }
    save_transfers(transfers)

    # Push notification to receiver via SocketIO
    receiver_sid = online_users.get(receiver)
    if receiver_sid:
        socketio.emit('transfer_request', {
            'tid':      tid,
            'sender':   session['username'],
            'sender_display': session['display'],
            'filename': safe,
            'size_hr':  human_size(len(raw)),
        }, to=receiver_sid)

    return jsonify({'ok': True, 'tid': tid})

@app.route('/api/transfer/respond', methods=['POST'])
@login_required
def api_transfer_respond():
    """Receiver accepts or rejects."""
    d      = request.get_json(silent=True) or {}
    tid    = (d.get('tid') or '').strip()
    accept = bool(d.get('accept'))

    transfers = load_transfers()
    t = transfers.get(tid)
    if not t:
        return jsonify({'ok': False, 'error': 'Transfer not found'}), 404
    if t['receiver'] != session['username']:
        return jsonify({'ok': False, 'error': 'Not your transfer'}), 403
    if t['status'] != 'pending':
        return jsonify({'ok': False, 'error': 'Transfer already resolved'}), 400

    if accept:
        # Move encrypted file from temp to receiver's vault
        temp_path = os.path.join(BASE_DIR, 'temp_transfers', tid)
        if not os.path.exists(temp_path):
            return jsonify({'ok': False, 'error': 'File expired or missing'}), 410

        vault = user_vault(session['username'])
        dest  = os.path.join(vault, t['filename'])
        if os.path.exists(dest):
            base, ext = os.path.splitext(t['filename'])
            dest = os.path.join(vault, f"{base}_{uuid.uuid4().hex[:6]}{ext}")

        os.rename(temp_path, dest)
        t['status'] = 'accepted'
        status_msg  = 'accepted'
    else:
        temp_path = os.path.join(BASE_DIR, 'temp_transfers', tid)
        if os.path.exists(temp_path):
            os.remove(temp_path)
        t['status'] = 'rejected'
        status_msg  = 'rejected'

    save_transfers(transfers)

    # Notify sender
    sender_sid = online_users.get(t['sender'])
    if sender_sid:
        socketio.emit('transfer_response', {
            'tid':      tid,
            'filename': t['filename'],
            'receiver': session['username'],
            'receiver_display': session['display'],
            'accepted': accept,
        }, to=sender_sid)

    return jsonify({'ok': True, 'status': status_msg})

@app.route('/api/transfer/history')
@login_required
def api_transfer_history():
    me = session['username']
    transfers = load_transfers()
    result = []
    for tid, t in transfers.items():
        if t['sender'] == me or t['receiver'] == me:
            result.append({**t, 'tid': tid})
    result.sort(key=lambda x: x.get('created',''), reverse=True)
    return jsonify(result[:50])

# ─────────────────────────────────────────────────────────────────────────────
#  Error handlers
# ─────────────────────────────────────────────────────────────────────────────
@app.errorhandler(413)
def too_large(e):
    return jsonify({'ok': False, 'error': f'File exceeds {MAX_MB} MB limit'}), 413

# ─────────────────────────────────────────────────────────────────────────────
#  SocketIO events
# ─────────────────────────────────────────────────────────────────────────────
@socketio.on('connect')
def on_connect():
    username = session.get('username')
    if not username:
        return False  # reject connection
    online_users[username] = request.sid
    # Broadcast updated presence to everyone
    _broadcast_presence()

@socketio.on('disconnect')
def on_disconnect():
    username = session.get('username')
    if username and online_users.get(username) == request.sid:
        del online_users[username]
        _broadcast_presence()

def _broadcast_presence():
    users = load_users()
    payload = []
    for uname, sid in online_users.items():
        payload.append({
            'username': uname,
            'display':  users.get(uname, {}).get('display', uname),
        })
    socketio.emit('presence_update', payload)

# ─────────────────────────────────────────────────────────────────────────────
#  Entry point
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    import socket
    try:
        local_ip = socket.gethostbyname(socket.gethostname())
    except Exception:
        local_ip = '0.0.0.0'
    print(f'\n  ⬡  NestShare v3 — Encrypted P2P File Sharing')
    print(f'  ─────────────────────────────────────────────')
    print(f'  Local:   http://127.0.0.1:5000')
    print(f'  Network: http://{local_ip}:5000')
    print(f'  Files encrypted at rest with AES-128 (Fernet)')
    print(f'  Passwords hashed with bcrypt (12 rounds)')
    print(f'  Press Ctrl+C to stop.\n')
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
