# ⬡ NestShare v3 — Encrypted P2P LAN File Sharing

A secure, real-time file sharing app for your local network.

---

## Security Architecture

| Layer | Implementation |
|-------|---------------|
| Passwords | **bcrypt** with 12 rounds + per-password salt |
| File storage | **AES-128 Fernet** symmetric encryption at rest |
| Master key | Stored in `.secret_key` (chmod 600, never committed) |
| Session | Flask server-side session with random 32-byte secret |
| File access | Strict per-user isolation — no cross-user file access possible |
| Transfers | Files held encrypted in temp area until receiver accepts |

---

## Features

- 🔐 **Encrypted file vault** — every file encrypted before writing to disk
- 👥 **Live presence** — see who's online in real time via WebSocket
- 📤 **Send files** — pick an online user, send a file; they get a popup notification
- 📥 **Accept/Decline** — receiver must explicitly accept before file enters their vault
- 📋 **Transfer history** — full audit trail of sent/received transfers
- 📱 **Mobile + Desktop** — full responsive layout with bottom nav on mobile

---

## Quick Start

```bash
# 1. Extract the zip
unzip nestshare_v3.zip
cd nestshare_v3

# 2. Run
chmod +x start.sh
./start.sh
```

Access from any device on your network:
```
http://<your-kali-ip>:5000
```

---

## File Structure

```
nestshare_v3/
├── app.py              # Flask + SocketIO backend
├── requirements.txt    # Python dependencies
├── start.sh            # Setup & launch script
├── .secret_key         # AES master key (auto-generated, chmod 600)
├── .flask_secret       # Flask session key (auto-generated, chmod 600)
├── users.json          # User accounts (bcrypt hashed passwords)
├── transfers.json      # Transfer history/audit log
├── uploads/            # Encrypted user vaults
│   ├── alice/          # Alice's encrypted files
│   └── bob/            # Bob's encrypted files
├── inbox/              # (reserved for future use)
├── temp_transfers/     # Encrypted holding area for pending transfers
├── templates/          # Jinja2 HTML templates
└── static/             # CSS + JS
```

---

## How File Transfer Works

```
Sender                          Server                       Receiver
  │                               │                              │
  ├─ Choose file + recipient ────▶│                              │
  │                               │ Encrypt & store in temp/     │
  │                               │◀──────────────────────────── │
  │                               │ Push socket event ──────────▶│
  │                               │                   [Popup shown]
  │                               │                   User accepts│
  │                               │◀─────────────────────────────│
  │                               │ Move to receiver's vault      │
  │◀── Socket: accepted ──────────│                              │
  │                               │                              │
```

---

## Dependencies

- **Flask** — web framework
- **Flask-SocketIO** — real-time WebSocket communication
- **cryptography** — Fernet (AES-128) file encryption
- **bcrypt** — password hashing
- **eventlet** — async server for SocketIO

All installed automatically by `start.sh`.
